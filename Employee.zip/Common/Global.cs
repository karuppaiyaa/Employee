﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Common
{
    public static class Global
    {
        public static string ConnectionStringPostgreSQL { get; set; }
    }
}
